class OCR {
  async scanImage(file) {
    const formData = new FormData();
    formData.append('image', file);

    const response = await fetch('/.netlify/functions/ocr', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) throw new Error('OCR failed');
    return await response.json();
  }
}