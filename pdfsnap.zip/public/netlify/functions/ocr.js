const Tesseract = require('tesseract.js');

exports.handler = async (event) => {
  try {
    const { image } = JSON.parse(event.body);
    const { data: { text } } = await Tesseract.recognize(image);
    return {
      statusCode: 200,
      body: JSON.stringify({ text }),
      headers: { 'Content-Type': 'application/json' }
    };
  } catch (error) {
    return { 
      statusCode: 500,
      body: JSON.stringify({ error: 'Stellar OCR failure' })
    };
  }
};